# XP Scale (x10)

Ryujinx ExeFS mod for **Unicorn Overlord US 1.0.5**.

Multiplies **combat** EXP by **10** (grants and on-screen +EXP text).
Does not change book / item EXP.

## Install

1. Unzip - folder `xp_scale` with `exefs/`
2. Paste into Ryujinx mods, enable **xp_scale**
3. Fully quit Ryujinx, then boot

US 1.0.5 only. Only one XP scale zip at a time.
